
********************************************************************************
  README.txt for logintoboggan_content_access_integration.module for Drupal
********************************************************************************
Developed by Geoff Appleby (gapple - http://drupal.org/user/490940).

The Login Toboggan / Content Access Integration module provides information to 
Content Access module so that it is able to handle Non-validated users correctly
when optimizing permissions.  
If you do not make use of the Non-validated user role option this module is 
not required, but will not cause any ill-effects.
