<div class="block block-language">
  <?php print $content; ?>
</div>